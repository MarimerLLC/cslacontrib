The Business and Authorization Rules included in this sample have different origins.
The rules copyrighted "Marimer LLC" are subject to the Csla license included.
Other rules copyrighted "CslaGenFork project" are subject to MIT license.

2011 Aug 26

